package com.ashwani.employeeapi.stepdefinitions;

import com.ashwani.employeeapi.api.EmployeeApi;
import com.ashwani.employeeapi.context.TestContext;
import com.ashwani.employeeapi.reports.ExtentManager;
import com.ashwani.employeeapi.utils.ConfigReader;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static org.junit.jupiter.api.Assertions.*;

public class LoginSteps {

    private static final Logger LOGGER = LogManager.getLogger(LoginSteps.class);
    private final TestContext context;
    private final EmployeeApi employeeApi;

    public LoginSteps(TestContext context) {
        this.context = context;
        this.employeeApi = new EmployeeApi();
    }

    @Given("HR admin logs in successfully")
    public void hrAdminLogsInSuccessfully() {
        Response response = employeeApi.login(ConfigReader.get("username"), ConfigReader.get("password"));
        context.setResponse(response);
        assertEquals(200, response.statusCode(), "Login should return 200");
        String token = readToken(response);
        assertNotNull(token, "Token should be returned after login");
        assertFalse(token.isBlank(), "Token should not be blank");
        context.setToken(token);
        LOGGER.info("Login successful and token captured");
        ExtentManager.getTest().info("Login successful and token captured");
    }

    @When("HR admin submits invalid login credentials")
    public void hrAdminSubmitsInvalidLoginCredentials() {
        context.setResponse(employeeApi.login("wrongAdmin", "wrongPassword"));
        LOGGER.info("Invalid login request submitted");
    }

    @Then("login should be rejected")
    public void loginShouldBeRejected() {
        int statusCode = context.getResponse().statusCode();
        assertTrue(statusCode == 400 || statusCode == 401 || statusCode == 403,
                "Invalid login should return 400, 401 or 403 but returned " + statusCode);
        ExtentManager.getTest().pass("Invalid login rejected with status code: " + statusCode);
    }

    private String readToken(Response response) {
        String token = response.jsonPath().getString("token");
        if (token == null) {
            token = response.jsonPath().getString("accessToken");
        }
        if (token == null) {
            token = response.jsonPath().getString("jwt");
        }
        return token;
    }
}
