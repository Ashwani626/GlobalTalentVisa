package com.ashwani.employeeapi.hooks;

import com.ashwani.employeeapi.reports.ExtentManager;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Hooks {

    private static final Logger LOGGER = LogManager.getLogger(Hooks.class);

    @Before
    public void beforeScenario(Scenario scenario) {
        LOGGER.info("Starting scenario: {}", scenario.getName());
        ExtentManager.createTest(scenario.getName());
        ExtentManager.getTest().info("Scenario started");
    }

    @After
    public void afterScenario(Scenario scenario) {
        if (scenario.isFailed()) {
            LOGGER.error("Scenario failed: {}", scenario.getName());
            ExtentManager.getTest().fail("Scenario failed");
        } else {
            LOGGER.info("Scenario passed: {}", scenario.getName());
            ExtentManager.getTest().pass("Scenario passed");
        }
        ExtentManager.flushReport();
        ExtentManager.removeTest();
    }
}
