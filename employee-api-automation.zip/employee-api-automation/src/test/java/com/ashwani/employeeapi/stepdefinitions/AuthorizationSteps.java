package com.ashwani.employeeapi.stepdefinitions;

import com.ashwani.employeeapi.api.EmployeeApi;
import com.ashwani.employeeapi.context.TestContext;
import com.ashwani.employeeapi.model.Address;
import com.ashwani.employeeapi.model.ContactInfo;
import com.ashwani.employeeapi.model.Employee;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class AuthorizationSteps {

    private static final Logger LOGGER = LogManager.getLogger(AuthorizationSteps.class);
    private final TestContext context;
    private final EmployeeApi employeeApi;

    public AuthorizationSteps(TestContext context) {
        this.context = context;
        this.employeeApi = new EmployeeApi();
    }

    @When("user creates employee without token")
    public void userCreatesEmployeeWithoutToken() {
        context.setResponse(employeeApi.createEmployeeWithoutToken(sampleEmployee()));
        LOGGER.info("Create employee without token request submitted");
    }

    @When("user requests employees with invalid token")
    public void userRequestsEmployeesWithInvalidToken() {
        context.setResponse(employeeApi.getAllEmployees("invalid-token-value"));
        LOGGER.info("Get employees with invalid token request submitted");
    }

    @Then("authorization error should be returned")
    public void authorizationErrorShouldBeReturned() {
        int statusCode = context.getResponse().statusCode();
        assertTrue(statusCode == 401 || statusCode == 403,
                "Authorization failure should return 401 or 403 but returned " + statusCode);
    }

    private Employee sampleEmployee() {
        Address address = new Address("20 Fake Road", "Leeds", "LS1 1AA");
        ContactInfo contactInfo = new ContactInfo("without.token@example.com", "+447700900999", address);
        return new Employee("NoToken", "User", "1995-07-12", contactInfo);
    }
}
