package com.ashwani.employeeapi.api;

import com.ashwani.employeeapi.model.Employee;
import com.ashwani.employeeapi.utils.ConfigReader;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.given;

public class EmployeeApi {

    private final String loginEndpoint = ConfigReader.get("login.endpoint");
    private final String employeesEndpoint = ConfigReader.get("employees.endpoint");

    public EmployeeApi() {
        RestAssured.baseURI = ConfigReader.get("base.url");
    }

    public Response login(String username, String password) {
        Map<String, String> body = new HashMap<>();
        body.put("username", username);
        body.put("password", password);

        return given()
                .contentType(ContentType.JSON)
                .body(body)
                .when()
                .post(loginEndpoint);
    }

    public Response createEmployee(String token, Employee employee) {
        return givenWithToken(token)
                .body(employee)
                .when()
                .post(employeesEndpoint);
    }

    public Response createEmployeeWithoutToken(Employee employee) {
        return given()
                .contentType(ContentType.JSON)
                .body(employee)
                .when()
                .post(employeesEndpoint);
    }

    public Response createEmployeeWithRawBody(String token, Map<String, Object> body) {
        return givenWithToken(token)
                .body(body)
                .when()
                .post(employeesEndpoint);
    }

    public Response getAllEmployees(String token) {
        return givenWithToken(token)
                .when()
                .get(employeesEndpoint);
    }

    public Response getEmployeeById(String token, String employeeId) {
        return givenWithToken(token)
                .when()
                .get(employeesEndpoint + "/" + employeeId);
    }

    public Response getEmployeeByIdWithoutToken(String employeeId) {
        return given()
                .contentType(ContentType.JSON)
                .when()
                .get(employeesEndpoint + "/" + employeeId);
    }

    public Response updateEmployee(String token, String employeeId, Employee employee) {
        return givenWithToken(token)
                .body(employee)
                .when()
                .put(employeesEndpoint + "/" + employeeId);
    }

    public Response deleteEmployee(String token, String employeeId) {
        return givenWithToken(token)
                .when()
                .delete(employeesEndpoint + "/" + employeeId);
    }

    public Response deleteEmployeeWithoutToken(String employeeId) {
        return given()
                .contentType(ContentType.JSON)
                .when()
                .delete(employeesEndpoint + "/" + employeeId);
    }

    private io.restassured.specification.RequestSpecification givenWithToken(String token) {
        return given()
                .contentType(ContentType.JSON)
                .header("Authorization", "Bearer " + token);
    }
}
