package com.ashwani.employeeapi.stepdefinitions;

import com.ashwani.employeeapi.api.EmployeeApi;
import com.ashwani.employeeapi.context.TestContext;
import com.ashwani.employeeapi.model.Address;
import com.ashwani.employeeapi.model.ContactInfo;
import com.ashwani.employeeapi.model.Employee;
import com.ashwani.employeeapi.reports.ExtentManager;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

public class EmployeeSteps {

    private static final Logger LOGGER = LogManager.getLogger(EmployeeSteps.class);
    private final TestContext context;
    private final EmployeeApi employeeApi;

    public EmployeeSteps(TestContext context) {
        this.context = context;
        this.employeeApi = new EmployeeApi();
    }

    @When("HR admin creates a new employee")
    public void hrAdminCreatesANewEmployee() {
        Employee employee = buildEmployee("Amit", "TestUser");
        Response response = employeeApi.createEmployee(context.getToken(), employee);
        context.setResponse(response);

        int statusCode = response.statusCode();
        assertTrue(statusCode == 200 || statusCode == 201, "Create employee should return 200 or 201 but returned " + statusCode);

        String employeeId = readEmployeeId(response);
        assertNotNull(employeeId, "Employee id should be returned after creation");
        context.setEmployeeId(employeeId);

        LOGGER.info("Employee created with id: {}", employeeId);
        ExtentManager.getTest().info("Employee created with id: " + employeeId);
    }

    @Then("employee should be created successfully")
    public void employeeShouldBeCreatedSuccessfully() {
        assertNotNull(context.getEmployeeId(), "Employee id should be available");
        assertFalse(context.getEmployeeId().isBlank(), "Employee id should not be blank");
    }

    @Then("employee should be available in catalog")
    public void employeeShouldBeAvailableInCatalog() {
        Response response = employeeApi.getEmployeeById(context.getToken(), context.getEmployeeId());
        context.setResponse(response);
        assertEquals(200, response.statusCode(), "Get employee by id should return 200");
        assertTrue(response.asString().contains(context.getEmployeeId()), "Response should contain employee id");
        ExtentManager.getTest().pass("Employee found in catalog");
    }

    @When("HR admin requests all employees")
    public void hrAdminRequestsAllEmployees() {
        context.setResponse(employeeApi.getAllEmployees(context.getToken()));
        LOGGER.info("Get all employees request submitted");
    }

    @Then("employee list should be returned")
    public void employeeListShouldBeReturned() {
        assertEquals(200, context.getResponse().statusCode(), "Get all employees should return 200");
        assertFalse(context.getResponse().asString().isBlank(), "Employee list response should not be blank");
    }

    @When("HR admin updates the employee")
    public void hrAdminUpdatesTheEmployee() {
        Employee employee = buildEmployee("AmitUpdated", "TestUser");
        context.setResponse(employeeApi.updateEmployee(context.getToken(), context.getEmployeeId(), employee));
        int statusCode = context.getResponse().statusCode();
        assertTrue(statusCode == 200 || statusCode == 204, "Update employee should return 200 or 204 but returned " + statusCode);
        LOGGER.info("Employee update request submitted for id: {}", context.getEmployeeId());
    }

    @Then("updated employee details should be saved")
    public void updatedEmployeeDetailsShouldBeSaved() {
        Response response = employeeApi.getEmployeeById(context.getToken(), context.getEmployeeId());
        assertEquals(200, response.statusCode(), "Get updated employee should return 200");
        assertTrue(response.asString().contains("AmitUpdated"), "Updated first name should be available in response");
        ExtentManager.getTest().pass("Employee update verified");
    }

    @When("HR admin deletes the employee")
    public void hrAdminDeletesTheEmployee() {
        context.setResponse(employeeApi.deleteEmployee(context.getToken(), context.getEmployeeId()));
        int statusCode = context.getResponse().statusCode();
        assertTrue(statusCode == 200 || statusCode == 202 || statusCode == 204,
                "Delete employee should return 200, 202 or 204 but returned " + statusCode);
        LOGGER.info("Employee deleted with id: {}", context.getEmployeeId());
    }

    @Then("employee should no longer exist")
    public void employeeShouldNoLongerExist() {
        Response response = employeeApi.getEmployeeById(context.getToken(), context.getEmployeeId());
        int statusCode = response.statusCode();
        assertTrue(statusCode == 404 || statusCode == 400,
                "Deleted employee lookup should return 404 or 400 but returned " + statusCode);
        ExtentManager.getTest().pass("Deleted employee is no longer available");
    }

    @When("HR admin requests non existing employee")
    public void hrAdminRequestsNonExistingEmployee() {
        context.setResponse(employeeApi.getEmployeeById(context.getToken(), "Emp-not-existing-12345"));
        LOGGER.info("Non existing employee request submitted");
    }

    @Then("not found response should be returned")
    public void notFoundResponseShouldBeReturned() {
        int statusCode = context.getResponse().statusCode();
        assertTrue(statusCode == 400 || statusCode == 404,
                "Non existing employee should return 400 or 404 but returned " + statusCode);
    }

    @When("HR admin creates employee with missing mandatory data")
    public void hrAdminCreatesEmployeeWithMissingMandatoryData() {
        Map<String, Object> body = new HashMap<>();
        body.put("firstName", "MissingEmail");
        body.put("lastName", "User");
        body.put("dateOfBirth", "1991-01-10");
        context.setResponse(employeeApi.createEmployeeWithRawBody(context.getToken(), body));
        LOGGER.info("Create employee with missing mandatory data request submitted");
    }

    @Then("employee creation should be rejected")
    public void employeeCreationShouldBeRejected() {
        int statusCode = context.getResponse().statusCode();
        assertTrue(statusCode >= 400 && statusCode < 500,
                "Missing mandatory data should return 4xx but returned " + statusCode);
    }

    private Employee buildEmployee(String firstName, String lastName) {
        String email = "api.test." + UUID.randomUUID().toString().substring(0, 8) + "@example.com";
        context.setEmployeeEmail(email);
        Address address = new Address("10 Test Street", "London", "SW1A 1AA");
        ContactInfo contactInfo = new ContactInfo(email, "+447700900123", address);
        return new Employee(firstName, lastName, "1990-05-15", contactInfo);
    }

    private String readEmployeeId(Response response) {
        String id = response.jsonPath().getString("id");
        if (id == null) {
            id = response.jsonPath().getString("employeeId");
        }
        if (id == null) {
            id = response.jsonPath().getString("data.id");
        }
        return id;
    }
}
