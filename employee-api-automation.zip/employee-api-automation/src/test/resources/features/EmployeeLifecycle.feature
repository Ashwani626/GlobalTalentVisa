Feature: Employee lifecycle

  Scenario: HR admin creates updates and deletes an employee
    Given HR admin logs in successfully
    When HR admin creates a new employee
    Then employee should be created successfully
    And employee should be available in catalog
    When HR admin updates the employee
    Then updated employee details should be saved
    When HR admin deletes the employee
    Then employee should no longer exist
