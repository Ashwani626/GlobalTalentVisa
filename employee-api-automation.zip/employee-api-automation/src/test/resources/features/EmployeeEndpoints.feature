Feature: Employee API endpoints

  Scenario: Get all employees
    Given HR admin logs in successfully
    When HR admin requests all employees
    Then employee list should be returned

  Scenario: Get non existing employee
    Given HR admin logs in successfully
    When HR admin requests non existing employee
    Then not found response should be returned

  Scenario: Create employee with missing mandatory data
    Given HR admin logs in successfully
    When HR admin creates employee with missing mandatory data
    Then employee creation should be rejected
