Feature: Authorization validation

  Scenario: Invalid admin login is rejected
    When HR admin submits invalid login credentials
    Then login should be rejected

  Scenario: Create employee without token is rejected
    When user creates employee without token
    Then authorization error should be returned

  Scenario: Access employees with invalid token is rejected
    When user requests employees with invalid token
    Then authorization error should be returned
