# Employee Catalog API Automation

This is a small Java BDD REST API automation project for the Employee Catalog Management API exercise.

## Purpose

The project verifies that an HR administrator can:

- login successfully
- receive an authorization token
- create an employee
- retrieve employee details
- retrieve all employees
- update employee details
- delete an employee
- verify authorization checks

## Technology Used

- Java 25
- Maven
- Rest Assured
- Cucumber BDD
- JUnit 5
- PicoContainer
- Extent Reports
- Log4j2
- Jackson

## API Under Test

Base URL:

```text
https://apisforemployeecatalogmanagementsystem.onrender.com
```

Configured endpoints:

```text
POST   /hr/login
POST   /employees
GET    /employees
GET    /employees/{id}
PUT    /employees/{id}
DELETE /employees/{id}
```

## Project Structure

```text
src/test/java/com/ashwani/employeeapi

api             API methods using Rest Assured
context         Shared scenario state using PicoContainer
hooks           Cucumber hooks for report and log handling
model           Employee request model
reports         Extent report setup
runner          Cucumber JUnit 5 runner
stepdefinitions BDD step definitions
utils           Config reader
```

Feature files are available under:

```text
src/test/resources/features
```

## Scenarios Covered

- successful HR admin login
- invalid HR admin login
- create employee
- get employee by id
- get all employees
- update employee
- delete employee
- access without token
- access with invalid token
- create employee with missing mandatory data
- get non-existing employee

## Main Business Flow

```text
Login
Create Employee
Verify Employee Exists
Update Employee
Verify Updated Employee
Delete Employee
Verify Employee Removed
```

## Configuration

Update values in:

```text
src/test/resources/config.properties
```

Current values:

```text
base.url=https://apisforemployeecatalogmanagementsystem.onrender.com
username=admin1
password=securePassword
login.endpoint=/hr/login
employees.endpoint=/employees
```

## How to Run

From the project root folder:

```text
mvn test
```

## Reports and Logs

After execution:

```text
reports/cucumber-report.html
reports/extent-report-<timestamp>.html
logs/automation.log
```

## Notes

- Fake test data is generated during execution.
- Real personal data is not used.
- The project does not include exe, sh, bat, bin, or json files.
- Run `mvn clean` before zipping if you need to submit the project again.
